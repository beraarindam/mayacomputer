
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startPush('custom-css'); ?>
    <style type="text/css">
        .form-section-heading {
            background: linear-gradient(to right, #4e73df, #825ee4);
            padding: 12px;
            height: 44px;
        }
        .form-section-heading h5{
            color: #fff;
        }
        .card-body input{
            border-radius: 15px;
            padding: 8px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Payment</h4>
        </div>
    </div>
</div>
<!-- end page title -->
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header form-section-heading">
                <h5>Payment Confirm</h5>
            </div>
            <div class="card-body">
                                   <form action="<?php echo e(route('payment_confirm')); ?>" method="POST" class="text-center mx-auto mt-5">
                                       <?php echo csrf_field(); ?>
                                      <script
                                          src="https://checkout.razorpay.com/v1/checkout.js"
                                          data-key="rzp_test_Yyokf06rQ4WTfd"
                                    data-amount="<?php echo e(Session::get('amount')); ?>" 
                                          data-currency="INR"
                                    data-order_id="<?php echo e(Session::get('order_id')); ?>"
                                          data-buttontext="Payment Now"
                                          data-name="Maya Computer Center"
                                          data-description="Test transaction"
                                         
                                          data-theme.color="#c42222"
                                      ></script>
                                      <input type="hidden" custom="Hidden Element" name="hidden">
                                      </form>
                                     
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
    <script type="text/javascript">
        
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BTLAB\mayacomputer\resources\views/center/payment_confirm.blade.php ENDPATH**/ ?>