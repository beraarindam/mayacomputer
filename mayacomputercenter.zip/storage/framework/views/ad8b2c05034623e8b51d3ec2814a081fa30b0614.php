
<?php $__env->startSection('title', 'Set Fee'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
	
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-12">
		<div class="page-title-box d-sm-flex align-items-center justify-content-between">
			<h4 class="mb-sm-0 font-size-18">Set Fee</h4>
			<div class="page-title-right">
				<form>
					<select name='course_id' onChange='submit()' class='h6'>
						<option value='' selected>--Select Course--</option>
						<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($data->c_id); ?>" <?php if(request()->get('course_id') == $data->c_id): ?> selected <?php endif; ?>><?php echo e($data->c_short_name); ?> [<?php echo e($data->c_full_name); ?>]</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- end page title -->
<div class="card mb-4">
	<div class='card-header bg-secondary text-white font-weight-bold'>
		
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				<thead>
					<tr class="table_main_row">
						<th>Reg.No</th>
						<th>Student Name</th>
						<th>Mobile No</th>
						<th>Course Fee</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$income = 0;
						$expense = 0;
					?>
					<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($data->sl_reg_no); ?></td>
							<td><?php echo e($data->sl_name); ?></td>
							<td><?php echo e($data->sl_mobile_no); ?></td>
							<td>
								<input type="number" id="fees_amount_<?php echo e($data->sl_id); ?>" name="fees" value="<?php echo e($data->c_price); ?>">
								<button onclick="set_fee(<?php echo e($data->sl_id); ?>)" class="btn btn-sm btn-danger">Set Fee</button>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			
		</div>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
<script>
	function set_fee(student_id){
		var fees_amount = $('#fees_amount_'+student_id).val();
		$.ajax({
			url: "<?php echo e(route('set_fee_amount')); ?>",
			type: "get",
			data:{student_id,fees_amount},
			dataType: "json",
			success: function(response){
				if(response.status == 1){
					alert(response.msg);
				}
			}
		});
	}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BTLAB\mayacomputer\resources\views/center/set_fee/index.blade.php ENDPATH**/ ?>