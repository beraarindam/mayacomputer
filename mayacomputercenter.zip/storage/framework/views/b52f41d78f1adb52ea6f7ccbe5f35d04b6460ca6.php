
<?php $__env->startSection('title', 'Edit Center'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
		
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
	<div class="col-12">
		<div class="page-title-box d-sm-flex align-items-center justify-content-between">
			<h4 class="mb-sm-0 font-size-18">Center</h4>
		</div>
	</div>
</div>
<!-- end page title -->
<div class="row">
	<div class="col-lg-8">
		<form id='update_frm' method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="card">
				<div class="card-header bg-secondary text-white font-weight-bold">
					Center Edit
					<span class='float-right' style='float:right'>
						<a href="<?php echo e(route('center_list')); ?>" >  View All</a>
					<button class="btn btn-success btn-sm" id="update_btn" accesskey="s"> SAVE </button>                                    </span>
				</div>
				<div class="card-body"> 
					<div class='row'>
						
						<div class="col-md-6 mb-3">
							<div class="form-group mb-3">
								<label>Center Name</label>
								<input required class="form-control" placeholder="Center Name" type='text' value="<?php echo e($data->cl_center_name); ?>" name='center_name'>
							</div>
						</div>
						<div class="col-md-6 mb-3">
							<div class="form-group mb-3">
								<label>Center Director Name</label>
								<input required class="form-control" placeholder="Director Name" value="<?php echo e($data->cl_director_name); ?>" type='text' name='director_name'>
							</div>
						</div>
						<div class="col-md-6 mb-3">
							<div class="form-group mb-3">
								<label>Center Address</label>
								<input required class="form-control" placeholder="Address"  type='text' value="<?php echo e($data->cl_center_address); ?>" name='center_address'>
							</div>
						</div>
						<div class="col-md-6 mb-3">
							<div class="form-group mb-3">
								<label>Center Email</label>
								<input required class="form-control" placeholder="Email"  type='email' value="<?php echo e($data->cl_email); ?>" name='center_email'>
							</div>
						</div>
						<div class="col-md-6 mb-3">
							<div class="form-group mb-3">
								<label>Center Mobile</label>
								<input required class="form-control" placeholder="Mobile"  type='number' value="<?php echo e($data->cl_mobile); ?>" name='center_mobile'>
							</div>
						</div>
						<div class="col-md-12 mb-3">
							<?php if($data->cl_photo): ?>
								<img style="width: 100px;height: 106px;border: 5px solid #eee;" src="<?php echo e(asset('admin/center_image/').'/'.$data->cl_photo); ?>">
							<?php endif; ?>
						</div>
						<div class="col-md-6 mb-3">
							<div class="form-group mb-3">
								<label>Photo</label>
								<input class="form-control"  type='file' name='photo'>
							</div>
						</div>
					</div>
				</div>
				<!-- end select2 -->
			</div>
		</form>
			<!-- <div class="card-footer bg-white">
					<hr>
					
					<hr>
			</div> -->
		</div>
		<!-- end row -->
		</div> <!-- container-fluid -->
	</div>
	<!-- End Page-content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BTLAB\mayacomputer\resources\views/admin/center/edit.blade.php ENDPATH**/ ?>