
<?php $__env->startSection('title', 'Block Student List'); ?>
<?php $__env->startPush('custom-css'); ?>
	<style type="text/css">
		
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header bg-secondary text-white font-weight-bold">
					Block Student List
					<span class='float-right' style='float:right'>
						<a href="<?php echo e(route('add_student')); ?>">  <button class="btn btn-success btn-sm" > Add New Student</button></a>
				</div>
			<div class="card-body">
				<div class="card-body">
				    <table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				        <thead>
					        <tr class="table_main_row">
					        	<th>Center Code</th>
					        	<th>Reg.No</th>
					            <th>Student Name</th>
					            <th>Date of Birth</th>
					            <th>Course</th>
					            <th>Status</th>
					            <th>Image</th>
					            <th>Action</th>
					        </tr>
				        </thead>
				        <tbody>
				        	<?php $i=1; ?>
				        	<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				        		<tr>
				        			<td><?php echo e($data->cl_code); ?></td>
				        			<td><?php echo e($data->sl_reg_no); ?></td>
				        			<td>
				        				<a href="<?php echo e(route('student_application', $data->sl_id)); ?>" target="__blank" ><?php echo e($data->sl_name); ?></a>
				        			</td>
				        			<td><?php echo e($data->sl_dob); ?></td>
				        			<td><?php echo e($data->c_short_name); ?></td>
				        			<td><?php echo e($data->sl_status); ?></td>
				        			<td>
				        				<img style="width: 47px;" src="<?php echo e(asset('center/student_doc/').'/'.$data->sl_photo); ?>">
				        			</td>
				        			<td>
				        				<a href="<?php echo e(route('edit_student', $data->sl_id)); ?>" class="btn btn-primary btn-sm"><i class="fa-regular fa-eye"></i></a>
				        			</td>
				        		</tr>
				        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BTLAB\mayacomputer\resources\views/center/student/block_student.blade.php ENDPATH**/ ?>