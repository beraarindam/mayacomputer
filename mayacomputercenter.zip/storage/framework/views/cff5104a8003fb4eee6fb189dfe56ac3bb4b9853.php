
<?php $__env->startSection('title', 'Student List'); ?>
<?php $__env->startPush('custom-css'); ?>
	<style type="text/css">
		
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header bg-secondary text-white font-weight-bold">
					Student List
					<span class='float-right' style='float:right'>
						
				</div>
			<div class="card-body">
				<div class="card-body">
				    <table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				        <thead>
					        <tr class="table_main_row">
					        	<th>Center Code</th>
					        	<th>Reg.No</th>
					            <th>Student Name</th>
					            <th>Image</th>
					            <th>Date of Birth</th>
					            <th>Course</th>
					            <th>Status</th>
					  
					            <th>Action</th>
					            <th>Operation</th>
					        </tr>
				        </thead>
				        <tbody>
				        	<?php $i=1; ?>
				        	<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				        		<tr>
				        			<td><?php echo e($data->cl_code); ?></td>
				        			<td><?php echo e($data->sl_reg_no); ?></td>
				        			<td><a href="<?php echo e(route('student_application_view', $data->sl_id)); ?>" target="__blank"><?php echo e($data->sl_name); ?></a></td>
				        			<td>
				        				<img style="width: 35px;height: 37px;" src="<?php echo e(asset('center/student_doc/').'/'.$data->sl_photo); ?>">
				        			</td>
				        			<td><?php echo e(date($data->sl_dob,strtotime(date('Y-m-d')))); ?></td>
				        			<td><?php echo e($data->c_short_name); ?></td>
				        			<td><?php echo e($data->sl_status); ?></td>
				        			<td>
				        				<form method="get">
				        					<?php echo csrf_field(); ?>
				        					<select name="student_status" onchange="studentStatus(this.value,<?php echo e($data->sl_id); ?>);">
				        						<option>--Select--</option>
				        						<option value="PENDING">PENDING</option>
				        						<option value="VERIFIED">VERIFIED</option>
				        						<option value="RESULT UPDATED">RESULT UPDATED</option>
				        						<option value="RESULT OUT">RESULT OUT</option>
				        						<option value="DISPATCHED">DISPATCHED</option>
				        						<option value="BLOCK">BLOCK</option>
				        					</select>
				        				</form>
				        			</td>
				        			<td>
				        				<a href="#" title="Print Certificate" class="btn btn-primary btn-sm"><i class="fa fa-print"></i></a>

				        				<a href="#" title="Print Marksheet" class="btn btn-success btn-sm"><i class="fa fa-print"></i></a>

				        				<a href="#" title="Send Certificate" class="btn btn-warning btn-sm"><i class="fa fa-share-square"></i></a>

				        				<a href="#" title="Print Marksheet" class="btn btn-dark btn-sm"><i class="fa fa-print"></i></a>
				        				
				        			</td>
				        		</tr>
				        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
	<script type="text/javascript">
		function studentStatus(status,student_id){
			$.ajax({
				url : "<?php echo e(route('student_status_updated')); ?>",
				method: "get",
				data:{status:status,student_id:student_id},
				dataType: "json",
				success: function(response){
					if(response.status == 1){
						alert(response.msg);
						location.reload();
					}else{
						alert(response.msg);
					}
				}
			});
		}
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BTLAB\mayacomputer\resources\views/admin/student/index.blade.php ENDPATH**/ ?>